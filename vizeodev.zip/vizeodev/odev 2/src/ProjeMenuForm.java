import javax.swing.*;

public class ProjeMenuForm {
    private JFrame frame;
    private JButton dersKayitButton;
    private JButton ogrenciKayitButton;

    public ProjeMenuForm() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Proje Menü");
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        dersKayitButton = new JButton("Ders Kayıt Formu");
        dersKayitButton.addActionListener(e -> {
            DersKayitForm dersKayitForm = new DersKayitForm();
            dersKayitForm.show();
        });
        dersKayitButton.setBounds(138, 67, 162, 41);
        frame.getContentPane().add(dersKayitButton);

        ogrenciKayitButton = new JButton("Öğrenci Kayıt Formu");
        ogrenciKayitButton.addActionListener(e -> {
            OgrenciKayitForm ogrenciKayitForm = new OgrenciKayitForm();
            ogrenciKayitForm.show();
        });
        ogrenciKayitButton.setBounds(138, 135, 162, 41);
        frame.getContentPane().add(ogrenciKayitButton);
    }

    public void show() {
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }

            ProjeMenuForm projeMenuForm = new ProjeMenuForm();
            projeMenuForm.show();
        });
    }
}
